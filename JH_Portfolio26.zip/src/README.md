# Personal Portfolio - Inspirations & Notes

## Project Overview
This is my personal portfolio website showcasing my work and skills.

## Design Inspirations
- 

## Technical Notes
- 

## Content Ideas
- 

## Future Improvements
- 

---
*Use this file to record your thoughts, inspirations, and ideas for your portfolio.*
https://21st.dev/community/components/dillionverma/rainbow-button/default
https://21st.dev/community/components/Codehagen/display-cards/default


Rainbow Gradient
hsl(210 100% 63% / 0.08) 30%,
hsl(270 100% 63% / 0.06) 45%,