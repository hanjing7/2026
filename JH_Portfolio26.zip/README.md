
  # Add Display Cards Component

  This is a code bundle for Add Display Cards Component. The original project is available at https://www.figma.com/design/rdA7AnMtOc3zoAs1kUsgFP/Add-Display-Cards-Component.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  